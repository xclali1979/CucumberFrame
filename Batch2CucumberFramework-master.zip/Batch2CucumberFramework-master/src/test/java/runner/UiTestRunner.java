package runner;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features ="src/test/resources/uiFeatures",
        glue = "stepDefs",
        dryRun = false,
        tags = "@TECTC-1012"
)
public class UiTestRunner {
}
